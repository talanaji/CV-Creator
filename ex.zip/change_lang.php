<?php ob_start(); session_start();
 $_SESSION['lang']= $_POST['lang'];
 
?>